// Contenido eliminado o movido a archivos JS específicos por slide
// Puedes dejar este archivo vacío o eliminarlo si no hay scripts globales
